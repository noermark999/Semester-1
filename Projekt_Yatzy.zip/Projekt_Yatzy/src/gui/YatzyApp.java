package gui;

import javafx.application.Application;

public class YatzyApp {

	public static void main(String[] args) {
		Application.launch(YatzyGui.class);
	}
}
