package Application.Model;

public enum BilMærke {
    BMW, AUDI, PEUGEOT, VOLVO
}
