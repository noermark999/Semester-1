package Application.Model;

public enum Varekategori {
    STUDIEBOG, MOBILTELEFON, COMPUTER, TØJ, ANDET
}
