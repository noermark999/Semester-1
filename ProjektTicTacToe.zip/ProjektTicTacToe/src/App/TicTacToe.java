package App;

import gui.Gui;
import javafx.application.Application;

public class TicTacToe  {
    public static void main(String[] args) {
        Application.launch(Gui.class);
    }


}
